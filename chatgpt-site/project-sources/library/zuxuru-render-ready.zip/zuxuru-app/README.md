# Zuxuru — Render-ready app

This is the Zuxuru Business Growth Operating System test application prepared for deployment on Render.

## Render settings

- Service type: Web Service
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/health`
- Node: 20+

The server listens on `0.0.0.0` and uses Render's `PORT` environment variable.

## Current scope

The UI is self-contained and does not require external network requests. It clearly labels simulated/test observations and does not present them as verified public evidence.

Live investigation connectors (search, listings, websites, social platforms, authorized business data) should be connected after deployment.
