const $=s=>document.querySelector(s);
const form=$('#scoreForm'), modal=$('#scoreModal'), business=$('#businessName'), modalScore=$('#modalScore'), modalTitle=$('#modalTitle'), modalText=$('#modalText'), toast=$('#toast');
function showToast(msg){toast.textContent=msg;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2600)}
function scoreFor(name){let n=[...name].reduce((a,c)=>a+c.charCodeAt(0),0);return 58+(n%27)}
form.addEventListener('submit',e=>{e.preventDefault();const name=business.value.trim();if(!name)return;const score=scoreFor(name);modalScore.textContent=score;modalTitle.textContent=`${name} is ready to be seen.`;modalText.textContent=`Zuxuru found an initial public visibility score of ${score}/100. Connect your business to replace the estimate with deeper, evidence-based intelligence.`;modal.classList.remove('hidden');localStorage.setItem('zuxuru_business',name);localStorage.setItem('zuxuru_score',score)});
$('[data-close]').addEventListener('click',()=>modal.classList.add('hidden'));modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.add('hidden')});
$('#continueBtn').addEventListener('click',()=>{modal.classList.add('hidden');showToast('Business saved. Your Zuxuru workspace is ready.');document.querySelector('#product').scrollIntoView({behavior:'smooth'})});
$('#startBtn').addEventListener('click',()=>{business.focus();window.scrollTo({top:document.querySelector('.hero').offsetTop-50,behavior:'smooth'})});
$('#loginBtn').addEventListener('click',()=>showToast('Login will connect to the production authentication service.'));
$('#howBtn').addEventListener('click',()=>document.querySelector('.how-section').scrollIntoView({behavior:'smooth'}));
$('#playBtn').addEventListener('click',()=>showToast('Demo video placeholder — connect the final Zuxuru brand video here.'));
if(localStorage.getItem('zuxuru_business')) business.value=localStorage.getItem('zuxuru_business');
