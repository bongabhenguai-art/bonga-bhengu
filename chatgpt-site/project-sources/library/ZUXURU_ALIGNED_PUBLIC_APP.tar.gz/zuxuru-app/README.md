# Zuxuru public website

This build aligns the public Zuxuru experience with the supplied reference image: announcement bar, dark/purple navigation, Be Found / Be Chosen / Be Alive hero, visibility-score entry, video panel, trust/stat strip and six feature pillars.

## Run locally

Open `index.html` directly, or serve this folder with any static web server.

## Current behavior

- Business-name visibility check opens an initial score modal.
- Score is deterministic demo logic and is clearly described as a public estimate.
- Business name and score persist in browser localStorage.
- Navigation and CTA buttons work.
- The video panel is a visual placeholder until the final Zuxuru video is supplied.

## Production connection

For real SaaS behavior, connect the UI to authentication, database, public discovery/visibility services, OAuth integrations, storage, background jobs and publishing/performance APIs. Never present simulated data as live platform data.
