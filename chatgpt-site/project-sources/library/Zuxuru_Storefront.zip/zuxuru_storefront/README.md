# Zuxuru Storefront

A standalone responsive storefront prototype for the Zuxuru Business Visibility & Growth Platform.

Open `index.html` in a browser.

The "Start investigation" form is a front-end prototype; connect it to the Zuxuru Investigation API when the backend is wired.
