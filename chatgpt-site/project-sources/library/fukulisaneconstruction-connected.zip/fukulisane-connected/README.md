# Fukulisane Construction — connected version

This keeps the existing website design and adds a real lead system.

## 1. Supabase
Create a Supabase project. In SQL Editor, run `supabase.sql` after replacing `REPLACE_WITH_ADMIN_EMAIL` with the admin email.

Create an Auth user for that admin email.

## 2. Netlify environment variables
Set these in Site configuration → Environment variables:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Use the project's public/publishable key (legacy `anon` key is also compatible). Never put a service-role/secret key in the site.

Redeploy. The public quote form will write leads to `project_enquiries`, and `/admin` will provide the authenticated dashboard.

The Netlify Forms attributes remain in the public form as a fallback if Supabase is not configured.
