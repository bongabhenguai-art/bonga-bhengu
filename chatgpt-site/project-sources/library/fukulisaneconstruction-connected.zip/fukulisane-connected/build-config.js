const fs = require('fs');
const url = process.env.SUPABASE_URL || '';
const key = process.env.SUPABASE_ANON_KEY || '';
fs.writeFileSync('supabase-config.js', `window.FUKULISANE_SUPABASE={url:${JSON.stringify(url)},anonKey:${JSON.stringify(key)}};\n`);
console.log(url ? 'Supabase config generated.' : 'Supabase env vars not set; Netlify Forms remains available.');
