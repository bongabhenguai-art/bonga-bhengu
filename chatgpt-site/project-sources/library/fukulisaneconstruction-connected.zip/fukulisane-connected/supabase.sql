-- Fukulisane Construction lead system
create extension if not exists pgcrypto;

create table if not exists public.project_enquiries (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  phone text,
  project_type text not null,
  location text,
  budget text,
  message text not null,
  status text not null default 'new' check (status in ('new','contacted','quoted','won','lost')),
  admin_notes text
);

alter table public.project_enquiries enable row level security;

revoke all on public.project_enquiries from anon, authenticated;
grant insert on public.project_enquiries to anon, authenticated;

create policy "Public can submit project enquiries"
on public.project_enquiries
for insert to anon, authenticated
with check (true);

-- Admin access: create your admin user in Supabase Auth, then run this policy.
-- Replace the email with the actual admin email.
create policy "Admin can read project enquiries"
on public.project_enquiries
for select to authenticated
using ((select auth.jwt()->>'email') = 'REPLACE_WITH_ADMIN_EMAIL');

create policy "Admin can update project enquiries"
on public.project_enquiries
for update to authenticated
using ((select auth.jwt()->>'email') = 'REPLACE_WITH_ADMIN_EMAIL')
with check ((select auth.jwt()->>'email') = 'REPLACE_WITH_ADMIN_EMAIL');
