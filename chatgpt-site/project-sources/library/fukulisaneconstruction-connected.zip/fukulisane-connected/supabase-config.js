window.FUKULISANE_SUPABASE={url:'',anonKey:''};
