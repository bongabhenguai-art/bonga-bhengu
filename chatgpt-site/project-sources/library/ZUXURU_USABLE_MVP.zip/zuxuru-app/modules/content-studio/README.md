# Zuxuru Digital Content Creation & Visibility Studio

This module is aligned to the master specification. It owns capture intake, content analysis, creation/repurposing, approval, distribution, performance measurement and learning. It is part of Zuxuru, not a separate product.
