# Zuxuru — Usable MVP

This is a browser-runnable Zuxuru workspace. It is functional without external accounts: business setup, local visibility scoring, content uploads, campaign generation, connection state and performance logging persist in browser localStorage.

## Run
Open `index.html` in a modern browser, or serve the folder with any static web server.

## Production integration boundary
Real Google/social OAuth, Supabase persistence, Logto authentication, publishing providers and AI media services require provider credentials and authorized connections. This MVP does not pretend those are live.
