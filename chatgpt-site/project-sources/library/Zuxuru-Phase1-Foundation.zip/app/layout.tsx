import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'Zuxuru — Digital Visibility Growth',description:'Zuxuru Phase 1 foundation prototype'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
