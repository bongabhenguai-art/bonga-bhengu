# Zuxuru Phase 1 Foundation

This is a runnable Phase 1 product shell. It implements business creation, persistent local business profile, evidence-status findings, dashboard navigation, and explicit prototype/verification boundaries.

## Run
npm install
npm run dev

## Important
Live DeepSearch, external account OAuth, provider APIs, Supabase persistence, and real publishing are intentionally not faked in this prototype. They require real credentials/connectors and will be added as separately testable integrations.
