import React from 'react';
export const metadata = { title: 'Zuxuru Digital Studio', description: 'Create, record, publish and grow.' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body style={{margin:0,fontFamily:'system-ui,sans-serif',background:'#f6f6f3'}}>{children}</body></html>}
