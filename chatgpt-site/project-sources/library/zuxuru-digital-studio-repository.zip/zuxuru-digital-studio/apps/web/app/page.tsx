const modules = [
 ['Website Builder','Build websites around the business growth goal.'],
 ['All-Platforms Builder','Create one source asset and adapt it across channels.'],
 ['Social Builder','Create posts, reels, stories, carousels and campaigns.'],
 ['Phone Camera','Turn the customer phone into the production camera.'],
 ['Recording Studio','Record, organize, transcribe and edit.'],
 ['Podcast Studio','Create episodes, clips, transcripts and show notes.'],
 ['Livestream Studio','Plan, run, record and repurpose live sessions.'],
 ['Growth','Connect hooks, offers, leads, closes and results.']
];
export default function Home(){return <main style={{maxWidth:1180,margin:'0 auto',padding:32}}>
<header style={{padding:'24px 0 42px'}}><b>ZUXURU DIGITAL STUDIO</b><h1 style={{fontSize:52,maxWidth:820,lineHeight:1.02}}>One studio for the entire digital growth journey.</h1><p style={{fontSize:19,lineHeight:1.6,maxWidth:760}}>Website, social, phone-camera recording, livestream, podcast and publishing — connected to the Zuxuru Growth Operating System.</p><button style={button}>Open Studio</button></header>
<section style={hero}><b>THE GROWTH LOOP</b><h2>Blockage → Hook → Offer → Content → Lead → Close → Result → Next Hook</h2><p>The Studio turns opportunities discovered by Zuxuru into actual digital assets and campaigns.</p></section>
<section><h2>Studio</h2><div style={grid}>{modules.map(([title,desc])=><article style={card} key={title}><h3>{title}</h3><p>{desc}</p><button style={link}>Open →</button></article>)}</div></section>
<section style={{marginTop:42}}><h2>Phone Camera Workflow</h2><div style={card}><ol><li>Zuxuru tells the business what to record.</li><li>The owner records with the phone.</li><li>Studio ingests and analyses the footage.</li><li>AI creates edits, captions, hooks, thumbnails and platform versions.</li><li>The business approves.</li><li>Zuxuru publishes and measures results.</li></ol></div></section>
</main>}
const button={border:'none',borderRadius:10,padding:'13px 18px',fontWeight:700,cursor:'pointer'};
const link={border:'none',background:'transparent',padding:0,fontWeight:700};
const hero={padding:30,borderRadius:18,background:'#fff',border:'1px solid #e4e4e4',marginBottom:36};
const grid={display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:16};
const card={padding:22,borderRadius:16,background:'#fff',border:'1px solid #e4e4e4'};
