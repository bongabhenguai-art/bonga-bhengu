const modules = [
  { href: '/studio/website', title: 'Website Builder', text: 'Build pages, landing pages, CTAs and conversion journeys.' },
  { href: '/studio/social', title: 'Social Builder', text: 'Create platform-specific posts, reels, stories and campaigns.' },
  { href: '/studio/camera', title: 'Phone Camera', text: 'Use the phone as the capture device for guided shoots.' },
  { href: '/studio/recording', title: 'Recording', text: 'Record, review, organize and prepare footage.' },
  { href: '/studio/podcast', title: 'Podcast', text: 'Episodes, transcripts, clips, show notes and publishing.' },
  { href: '/studio/livestream', title: 'Livestream', text: 'Plan, run, record and repurpose live sessions.' },
  { href: '/studio/content', title: 'Content Engine', text: 'Turn one source recording into a complete content package.' },
];

export default function StudioHome() {
  return (
    <main style={{maxWidth:1200,margin:'0 auto',padding:32}}>
      <a href="/" style={{textDecoration:'none'}}>← Zuxuru</a>
      <h1 style={{fontSize:48,marginBottom:8}}>Digital Studio</h1>
      <p style={{fontSize:19,maxWidth:760,lineHeight:1.6}}>One workspace for websites, social, phone-camera production, recording, podcasting, livestreaming and publishing.</p>
      <section style={{marginTop:32,padding:24,border:'1px solid #ddd',borderRadius:18,background:'#fff'}}>
        <strong>Growth-connected studio</strong>
        <p style={{lineHeight:1.6}}>Every project can start from a growth blockage, hook or offer and end with published content and measurable results.</p>
      </section>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:16,marginTop:24}}>
        {modules.map(m=><a key={m.href} href={m.href} style={{textDecoration:'none',color:'inherit',padding:22,border:'1px solid #ddd',borderRadius:16,background:'#fff'}}><h2>{m.title}</h2><p style={{lineHeight:1.5}}>{m.text}</p><b>Open →</b></a>)}
      </div>
    </main>
  );
}
