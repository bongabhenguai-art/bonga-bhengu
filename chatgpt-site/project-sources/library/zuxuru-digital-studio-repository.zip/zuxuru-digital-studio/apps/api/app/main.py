from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI(title='Zuxuru Digital Studio API', version='0.1.0')
class Project(BaseModel):
    name: str
    type: str
    goal: str | None = None
@app.get('/health')
def health(): return {'status':'ok','service':'zuxuru-studio-api'}
@app.get('/api/studio/modules')
def modules(): return {'modules':['website_builder','all_platforms_builder','social_builder','phone_camera','recording_studio','podcast_studio','livestream_studio','content_engine','publishing','growth_measurement']}
@app.post('/api/studio/projects')
def create_project(project: Project): return {'id':'project-demo-001','status':'draft','project':project.model_dump()}
