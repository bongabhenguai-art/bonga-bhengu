# Core domain contracts

Business, GrowthBlockage, Opportunity, Hook, Offer, ContentProject, Recording, Asset, Website, SocialPost, PodcastEpisode, Livestream, Lead, ClosePackage, Publication and Result.
