# podcast adapter\n\nPlatform/provider integrations belong here. Keep Zuxuru's core workflow provider-independent.
