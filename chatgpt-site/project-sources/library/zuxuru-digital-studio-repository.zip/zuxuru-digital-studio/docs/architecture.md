# Architecture

## Studio modules

1. Website Builder — pages, sections, forms, CTAs, brand kit, publishing.
2. All-Platforms Builder — one source content adapted to platform-specific formats.
3. Social Builder — posts, reels, stories, carousels, captions, scheduling.
4. Phone Camera — guided recording tasks from a phone browser.
5. Recording Studio — ingest, review, trim, organize, transcribe.
6. Podcast Studio — episodes, audio/video, transcript, clips, show notes.
7. Livestream Studio — sessions, scenes, destinations, recording, repurposing.
8. Content Engine — turn one source recording into many assets.
9. Publishing — approval, scheduling, platform adapters, status.
10. Growth Measurement — content → leads → opportunities → closes → results.

## Adapter interfaces

- WebsiteAdapter
- SocialAdapter
- StreamingAdapter
- PodcastAdapter
- StorageAdapter
- AIEditingAdapter
- AnalyticsAdapter
- PublishingAdapter

The core product must remain independent from any single external provider.
