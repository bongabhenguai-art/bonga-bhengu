# GitHub handoff

The project is already a local Git repository. To publish it to GitHub, connect GitHub through the authorized integration and create a repository named `zuxuru-digital-studio` (or choose an existing repository).

Recommended branch flow:

- `main` — production
- `develop` — integration
- feature branches — individual Studio modules

Do not commit secrets. Use environment variables for platform credentials and OAuth tokens.
