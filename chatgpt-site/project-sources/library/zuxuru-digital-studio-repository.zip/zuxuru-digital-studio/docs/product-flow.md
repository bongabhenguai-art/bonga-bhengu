# Product flows

## Website
Business/growth goal → sitemap → AI-assisted sections → brand → CTA/forms → preview → publish → measure.

## Social
Hook → offer → content source → platform variants → approval → schedule/publish → measure.

## Phone camera
Zuxuru identifies required content → AI Director gives shot instructions → phone records → upload → select/edit → captions/branding → approval → publish.

## Recording
Create project → record/upload → organize scenes → transcript → edit → clips → publish.

## Podcast
Create show → create episode → record/upload → transcript → chapters/show notes → clips → publish.

## Livestream
Create live session → select destinations → configure scenes → start → record → stop → repurpose → follow up with leads.
