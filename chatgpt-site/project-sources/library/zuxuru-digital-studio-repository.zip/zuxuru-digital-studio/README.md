# Zuxuru Digital Studio

A growth-driven digital studio for businesses: website building, all-platform content creation, social publishing, phone-camera recording, livestreaming, podcasting, editing, publishing, and growth measurement.

## Core loop

**Growth blockage → Opportunity → Hook → Offer → Content → Capture → Studio → Publish → Lead → Close → Result → Next Hook**

## Included in this starter repository

- Website Builder
- All-Platforms Content Builder
- Social Builder
- Phone Camera Capture
- Recording Studio
- Livestream Studio
- Podcast Studio
- Content/AI editing adapter layer
- Brand Kit and Asset Library contracts
- Publishing queue contracts
- Growth/lead/close handoff contracts
- Next.js web starter
- FastAPI API starter

## Architecture

```text
ZUXURU GROWTH ENGINE
        |
        +-- Investigation / Growth Blockages
        |
        +-- Hook / Offer / Campaign
        |
        v
DIGITAL STUDIO
  |       |       |       |
Web    Social   Camera  Live/Podcast/Recording
  |       |       |       |
  +-------+-------+-------+
          |
       AI EDITING
          |
       PUBLISHING
          |
         LEADS
          |
      CLOSE PACKAGE
          |
        RESULT
          |
       LEARNING
```

External platforms are adapters. Zuxuru owns the workflow, content model, brand system, permissions, evidence, scheduling, and growth logic.

## Run

### Web
```bash
cd apps/web
npm install
npm run dev
```

### API
```bash
cd apps/api
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
