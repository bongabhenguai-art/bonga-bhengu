# Zuxuru Investigation Platform

This is a runnable application foundation, not a visual mockup. It uses a provider-neutral investigation flow and a real DataForSEO connector when credentials are configured.

## Run
Node 18+ is sufficient; no npm packages are required.

```bash
DATAFORSEO_LOGIN=your_login DATAFORSEO_PASSWORD=your_password node server.js
```
Then open `http://localhost:3000`.

## Live investigation
The app uses DataForSEO Google Local Finder for business candidate discovery and Google Organic SERP for search visibility. DataForSEO documents these as live endpoints and returns source/check URLs with the result data. See the official documentation referenced in the build notes.

The app also fetches a confirmed public website directly from the server and extracts title, description, headings, public emails/phones and likely conversion links. No candidate or finding is fabricated when a connector is unavailable.

## Next production step
Connect Supabase for persistent multi-user storage, authentication and RLS; then add the remaining connectors behind the same investigation orchestrator.
