import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import OpenAI from 'openai';

const app = express();
const port = Number(process.env.PORT || 8787);
const upload = multer({ limits: { fileSize: 8 * 1024 * 1024 } });
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const SYSTEM = `You are an expert product designer and senior React engineer. Convert the supplied UI screenshot and user brief into a polished, functional React + Vite app.

Return ONLY valid JSON with this shape:
{"name":"string","description":"string","files":[{"path":"src/App.jsx","content":"..."},{"path":"src/main.jsx","content":"..."},{"path":"src/styles.css","content":"..."}],"notes":["..."]}

Rules:
- Generate a complete runnable React/Vite frontend.
- Use plain React and CSS; no external images unless the screenshot clearly requires them. Use the screenshot's visual language, spacing, typography and hierarchy.
- Use lucide-react for icons when useful.
- Make interactions functional: navigation, tabs, buttons, forms, toggles and menus shown in the design should work.
- Prefer a small number of clean files.
- Do not include markdown fences.
- Do not include secrets.
- Make the result responsive.
- The screenshot is the visual source of truth; the brief provides product behavior.`;

app.get('/api/health', (_req, res) => res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) }));

app.post('/api/generate', upload.single('image'), async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'OPENAI_API_KEY is not configured. Copy .env.example to .env and add your key.' });
  if (!req.file) return res.status(400).json({ error: 'Upload a screenshot first.' });
  const brief = String(req.body.brief || 'Recreate this interface faithfully as a working responsive web app.');
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.5',
      input: [{ role: 'user', content: [
        { type: 'input_text', text: `${SYSTEM}\n\nUSER BRIEF:\n${brief}` },
        { type: 'input_image', image_url: dataUrl }
      ] }]
    });
    const text = response.output_text?.trim();
    if (!text) throw new Error('Model returned no text.');
    const clean = text.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    const result = JSON.parse(clean);
    if (!result.files?.length) throw new Error('Generated project contained no files.');
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || 'Generation failed.' });
  }
});

app.listen(port, () => console.log(`Image-to-App server listening on http://localhost:${port}`));
