# Open-source Image-to-App Builder

A Base44-style local-first prototype: upload a screenshot, describe the app, generate a real React app, preview it, and export the generated source. MIT licensed.

## What it does
- Screenshot upload with preview
- Natural-language app brief
- Vision-capable AI generation through the OpenAI Responses API
- Generates a self-contained React/Vite project as source files
- In-browser code inspection
- Download generated project as JSON source bundle
- Local-first: your API key stays on the server

## Run
1. Install Node.js 20+.
2. `cp .env.example .env`
3. Add `OPENAI_API_KEY` and optionally `OPENAI_MODEL`.
4. `npm install`
5. `npm run dev`
6. Open `http://localhost:5173`

If no API key is configured, the UI still runs and shows setup instructions.

## Architecture
- `client/`: React + Vite builder UI
- `server/`: Express API and AI generation route
- Generated projects are returned as source files and can be downloaded as a JSON bundle.

## Roadmap
- Sandboxed live preview of generated projects
- Multi-file editing
- Git export
- Supabase auth/database scaffolding
- Provider adapters for Anthropic, Gemini and Ollama
- Drag-and-drop visual editor
