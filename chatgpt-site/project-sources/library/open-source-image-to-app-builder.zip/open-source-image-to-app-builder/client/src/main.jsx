import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Upload, Sparkles, Code2, Download, Image as ImageIcon, Check, AlertCircle} from 'lucide-react';
import './styles.css';

function App(){
  const [file,setFile]=useState(null), [preview,setPreview]=useState(''), [brief,setBrief]=useState('Build a responsive web app that matches this screenshot. Preserve the layout, typography, spacing, colors, cards, navigation and primary interactions.');
  const [busy,setBusy]=useState(false), [result,setResult]=useState(null), [selected,setSelected]=useState(0), [error,setError]=useState(''), [configured,setConfigured]=useState(null);
  useEffect(()=>{fetch('/api/health').then(r=>r.json()).then(x=>setConfigured(x.configured)).catch(()=>setConfigured(false));},[]);
  const current=useMemo(()=>result?.files?.[selected],[result,selected]);
  function onFile(f){if(!f)return; setFile(f); setPreview(URL.createObjectURL(f)); setError('');}
  async function generate(){
    if(!file){setError('Upload a screenshot first.');return;}
    setBusy(true);setError('');setResult(null);
    const fd=new FormData(); fd.append('image',file); fd.append('brief',brief);
    try{const r=await fetch('/api/generate',{method:'POST',body:fd}); const data=await r.json(); if(!r.ok)throw new Error(data.error||'Generation failed'); setResult(data); setSelected(0);}catch(e){setError(e.message)}finally{setBusy(false)}
  }
  function download(){
    if(!result)return; const blob=new Blob([JSON.stringify(result,null,2)],{type:'application/json'}); const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`${(result.name||'generated-app').replace(/[^a-z0-9-_]+/gi,'-')}.json`;a.click();
  }
  return <div className="app">
    <header><div className="brand"><div className="logo"><Sparkles size={18}/></div><div><b>Open App Forge</b><span>open-source image → app</span></div></div><div className="status">{configured===true?<><Check size={15}/> AI ready</>:configured===false?<><AlertCircle size={15}/> Add API key</>:null}</div></header>
    <main>
      <section className="hero"><div className="eyebrow">BASE44-STYLE • LOCAL-FIRST • MIT</div><h1>Turn any screenshot into a working app.</h1><p>Upload a design, explain the product, and generate editable React source code with your own AI key.</p></section>
      <section className="workspace">
        <aside className="panel left">
          <div className="panelTitle"><span>01</span><b>Design</b></div>
          <label className="drop" onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();onFile(e.dataTransfer.files?.[0])}}>
            {preview?<img src={preview} alt="Uploaded design"/>:<><ImageIcon size={30}/><strong>Drop screenshot here</strong><small>PNG, JPG or WEBP · up to 8 MB</small></>}
            <input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>onFile(e.target.files?.[0])}/>
          </label>
          <div className="panelTitle"><span>02</span><b>Brief</b></div>
          <textarea value={brief} onChange={e=>setBrief(e.target.value)} />
          <button className="generate" disabled={busy} onClick={generate}><Sparkles size={17}/>{busy?'Generating…':'Generate app'}</button>
          {error&&<div className="error"><AlertCircle size={16}/>{error}</div>}
          {configured===false&&<div className="hint">Server is running, but no <code>OPENAI_API_KEY</code> is configured. Add it to <code>.env</code> and restart.</div>}
        </aside>
        <section className="panel center">
          <div className="panelTitle"><span>03</span><b>Preview</b><em>{result?'Generated':'Waiting for input'}</em></div>
          <div className="previewFrame">
            {result?<div className="generatedPreview"><div className="mockNav">{result.name}<span>Live source preview</span></div><div className="mockBody"><h2>{result.name}</h2><p>{result.description}</p><div className="cards">{result.files.slice(0,3).map((f,i)=><div className="card" key={i}><Code2 size={18}/><b>{f.path}</b><small>{f.content.length.toLocaleString()} chars</small></div>)}</div></div></div>:preview?<img className="largeShot" src={preview} alt="Design preview"/>:<div className="empty"><Upload size={42}/><b>Your generated app will appear here</b><span>Upload a screenshot and click Generate app.</span></div>}
          </div>
        </section>
        <aside className="panel right">
          <div className="panelTitle"><span>04</span><b>Source</b><button className="iconBtn" disabled={!result} onClick={download}><Download size={16}/></button></div>
          {result?<><div className="tabs">{result.files.map((f,i)=><button className={i===selected?'active':''} onClick={()=>setSelected(i)} key={f.path}>{f.path}</button>)}</div><pre className="code"><code>{current?.content}</code></pre></>:<div className="sourceEmpty"><Code2 size={30}/><span>Generated files will be listed here.</span></div>}
        </aside>
      </section>
    </main>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
