# Zuxuru Growth Operating System — runnable MVP

This is a self-contained browser MVP. No build tools or external services are required.

## Run
Open `index.html` in a browser, or run a simple local server:

`python3 -m http.server 8080`

Then visit `http://localhost:8080`.

## Included
- Business-name investigation entry point
- Identity candidates + owner confirmation UI
- Investigation replay
- Evidence ledger with finding type/confidence/source
- Customer intelligence model
- Asset intelligence model
- Opportunity Graph
- Root-cause diagnosis
- Offer/solution surface
- Digital Studio preview
- Lead provenance
- Results/growth loop
- Responsive dashboard UI

The investigation currently uses deterministic demo evidence so the app works immediately. The next production layer is to connect the investigation orchestrator to live web/data providers, Supabase persistence, authentication, and approved platform integrations.
