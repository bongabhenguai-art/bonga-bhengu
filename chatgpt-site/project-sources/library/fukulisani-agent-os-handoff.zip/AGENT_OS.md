# Fukulisani Agent OS

Core agents:
Discovery, Visibility Scoring, Platform Intelligence, Customer Intelligence,
Opportunity, Brand, Content, Publishing, Reputation, SEO/Search, Marketing,
Monitoring, Optimization, CEO/Strategy.

Web Research Agent:
Research permitted public sources -> extract evidence -> normalize -> score -> recommend.

YouTube Automation Agent:
Topic -> research -> script -> title/description/thumbnail brief -> approval ->
authorized publish -> monitor -> optimize.

Every agent job follows:
Goal -> Tools -> Data permissions -> Rules -> Task -> Approval -> Execution ->
Result -> Measurement -> Learning.

External publishing requires authorization and appropriate approval.
