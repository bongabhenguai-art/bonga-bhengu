# Platform Registry

Extensible visibility universe.

Search: Google, Bing, Yahoo, DuckDuckGo, Brave, Ecosia, Yandex, Naver
Maps/local: Google Business Profile, Google Maps, Apple Maps, Bing Places, Yelp,
Nextdoor, Foursquare, Waze, HERE, MapQuest, OpenStreetMap, Tripadvisor
Social: Facebook, Instagram, TikTok, LinkedIn, X, Threads, Snapchat, Pinterest,
Reddit, Quora, Bluesky, Mastodon, Tumblr, WhatsApp, Telegram, Discord, WeChat, LINE
Video: YouTube, Vimeo, Dailymotion, Twitch, Rumble, Kick, PeerTube
Reviews: Trustpilot, BBB, TrustRadius, G2, Capterra, Clutch, GoodFirms, Glassdoor
Directories: Yellow Pages, Superpages, Manta, Hotfrog, Cylex, Brownbook, Kompass,
Dun & Bradstreet, Crunchbase, ZoomInfo
AI: Perplexity, ChatGPT, Gemini, Claude, Microsoft Copilot, Meta AI, You.com
Commerce: Amazon, eBay, Etsy, Walmart, Shopify, Google Merchant Center, Bing Shopping
Industry/marketplaces: OpenTable, DoorDash, Uber Eats, Grubhub, Booking.com, Expedia,
Airbnb, Zillow, Realtor.com, Redfin, Healthgrades, Zocdoc, Thumbtack, Bark, Upwork, Fiverr

The engine should score relevance by industry, geography, audience and intent rather
than requiring every business to exist everywhere.
