# Fukulisane Construction Platform — Consolidated Build History

## Product principle
Fukulisane Construction is the product. The storefront is the customer-facing face. Intelligence, engines, AI agents, integrations, scanners, CRM, marketing and other resources operate behind it to grow and operate the business.

## Storefront
- Attractive image-led construction storefront.
- Services catalogue with job-aligned photographic images, not emoji icons.
- Verified Fukulisane project photos are labelled as real projects.
- Concept/inspiration imagery is clearly labelled until replaced by verified company photography.
- Services include new home construction, renovations, roofing, painting, paving, boundary walls, extensions, kitchen/bathroom work and related construction services.
- Project catalogue, before/after, process, reviews, FAQs, service areas and customer education.
- Direct call, WhatsApp, quote and site-visit actions.
- Customer paths: first-time builder, landowner ready to build, homeowner renovating, premium professional customer.
- Storefront markets Fukulisane, not the internal technology.

## Owner platform
- Owner dashboard/control room.
- Leads, customers, quotations, projects, communications, documents and next actions.
- Manual editing of project/gallery content.
- Marketing, branding, SEO, social, revenue and business-improvement workspaces.
- Integration/connection status and official-source wizards.

## Intelligence engines
Business Intelligence; Visibility Intelligence; Marketing Intelligence; Branding Intelligence; SEO Intelligence; Social Intelligence; Opportunity Discovery; Lead Intelligence; Buyer Intelligence; Customer Readiness Intelligence; Personal Package Generator; Proposal Intelligence; Contract Intelligence; Pricing Intelligence; Trend Intelligence; Revenue Prediction; Business Improvement Intelligence; Design Intelligence; Plan Intelligence; Quantity/Materials Planning; Labour Intelligence; Construction Intelligence; Property Condition Intelligence; Sales Intelligence; Customer Intelligence; Review Intelligence; Referral Intelligence; Project Intelligence; Procurement Intelligence; Physical Footprint Intelligence; Digital Footprint Intelligence; Growth Intelligence.

Every engine follows:
REAL SOURCE -> INPUT -> PROCESS -> INSIGHT -> RECOMMENDATION -> OWNER ACTION -> RESULT -> MEASUREMENT.

No source data means NO DATA / CONNECT SOURCE / ADD INFORMATION. No fabricated scores, leads, reviews, traffic, social metrics or external-platform status.

## Construction planning
- Square metres (m²) is the primary measurement basis for construction planning/pricing.
- Economy, Standard and Premium design pathways with explanations.
- Plan reading from uploaded plans.
- Material planning.
- Labour roles, crew planning and sequence.
- Preliminary duration and cost allowances.
- Where m² is not technically appropriate, use the appropriate unit such as item, point, hour, day or lump sum.
- Final quantities, compliance and professional requirements must be verified against approved drawings, site conditions and qualified professionals.

## Property tools
- Phone camera/photo property-condition scan.
- Approximate measurement scan using a known reference length.
- Visible-condition findings and suggested repair pathways.
- Preliminary cost allowances only.
- No claim of hidden structural certainty from a photograph.

## Physical + digital growth
Real construction -> real project evidence -> storefront trust -> digital visibility -> enquiries -> sales -> projects -> reviews/referrals -> greater physical and digital footprint.

## Integrations
Official-source wizards for Google Business Profile, Google Search Console, Google Analytics, Meta/Facebook/Instagram, TikTok, YouTube, LinkedIn, Google Maps, email, WhatsApp Business API and advertising platforms.
A link/button is not a live connection. External services remain NOT CONNECTED until the real owner authorises and the source is verified.

## Languages
English, isiZulu, isiXhosa, Afrikaans, Sepedi, Sesotho, Setswana, siSwati, Tshivenda, Xitsonga, isiNdebele.

## Release gate
The platform should be publish-ready with the custom domain as the remaining public-branding step. External services still require their real owner authorisation/credentials; the platform must never simulate those connections.
