Current app status at history capture:
- Live AppDeploy URL exists.
- Frontend and backend runtime errors: none reported in latest QA.
- E2E tests: passed.
- Backend endpoint coverage was reported as 60% because POST /api/property/scan and POST /api/measure/photo were not exercised by the automated QA suite at the latest status check.
- Therefore the app should NOT be described as 100% QA-covered until those two routes are exercised.
