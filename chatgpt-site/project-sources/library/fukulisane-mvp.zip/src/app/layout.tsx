import './globals.css';
export const metadata={title:'Fukulisane — Visibility OS',description:'Continuous visibility improvement for businesses'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
