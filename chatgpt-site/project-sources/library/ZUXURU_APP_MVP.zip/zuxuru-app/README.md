# Zuxuru MVP

A browser-based, no-build prototype implementing the Zuxuru master architecture at the product-flow level.

## Run locally

```bash
python3 -m http.server 4173
```

Open http://localhost:4173

## What is functional in this MVP

- Zuxuru overview dashboard
- Visibility intelligence view
- Content Studio pipeline
- Multi-camera studio preview model
- Configurable 10-asset daily campaign concept
- Vault/connection lifecycle UI
- Growth loop / Business Graph model
- Interactive visibility scan demo
- Campaign creation and content-plan interactions

## Important

This is the first working product shell, not a claim that external services are connected. Real OAuth, Supabase persistence, publishing APIs, analytics ingestion, AI processing and production deployment require credentials, provider configuration and a real repository/environment.
