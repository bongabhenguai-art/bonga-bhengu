# Zuxuru Storefront

Public storefront prototype for Zuxuru, based on the approved digital-banner/video direction.

## Included
- Responsive Zuxuru landing page
- Digital hero banner with video-style presentation
- Business visibility input and demo scan interaction
- How-it-works modal
- Trust/metrics strip
- Six core product modules
- Responsive mobile layout

## Run
This prototype is dependency-free. Open `index.html` in a browser or serve this folder with any static web server.

## Next production step
Replace `assets/hero.png` with the final approved brand/video assets and connect the scan form to the real DeepSearch + Founding Name Visibility API.
