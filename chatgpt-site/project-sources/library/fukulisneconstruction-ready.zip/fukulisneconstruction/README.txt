FUKULISANE CONSTRUCTION WEBSITE

Files:
- index.html — complete responsive website
- netlify.toml — Netlify configuration

DEPLOY TO NETLIFY:
1. Sign in to Netlify.
2. Open https://app.netlify.com/drop
3. Drag this entire folder into the Drop zone.
4. In Netlify, set the site/project name to: fukulisneconstruction
5. The site will be available at: https://fukulisneconstruction.netlify.app

The contact form uses Netlify Forms and is ready to receive submissions once deployed.

Before public launch, replace/add the real business phone, email, physical address, service area, licence/registration details, project photos and testimonials if applicable.
