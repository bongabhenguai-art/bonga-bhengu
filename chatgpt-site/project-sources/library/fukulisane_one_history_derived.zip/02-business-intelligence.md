# Business Intelligence

Discover, verify, profile and score public digital visibility.

Inputs:
- business name
- domain/website
- public business identifiers

Discovery:
- search engines
- websites
- Google Business
- social media
- directories
- reviews
- SEO
- news
- public brand mentions
- competitors

Outputs:
- Business Profile
- Digital Visibility Map
- Evidence Repository
- Missing Platform Registry
- Existing Platform Registry
- 0–100 visibility scores
- Business Audit
