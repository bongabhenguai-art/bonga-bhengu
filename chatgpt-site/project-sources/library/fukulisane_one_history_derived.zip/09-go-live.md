# Go-Live Gate

A domain being connected does not automatically authenticate external services.

A capability is live only when:
- real input exists
- engine exists
- source works
- errors are handled
- authorization exists where required
- output is measurable
- QA passes

External providers may still require their own OAuth/API credentials and verification.
