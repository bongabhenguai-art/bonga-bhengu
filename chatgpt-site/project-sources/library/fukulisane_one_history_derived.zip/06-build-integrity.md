# Build Integrity Standard

A screen is not a working component.

Completion:
REAL INPUT
→ REAL ENGINE
→ REAL DATA SOURCE
→ REAL PROCESSING
→ REAL OUTPUT
→ AUDIT TRAIL
→ MEASURABLE RESULT

Rules:
- no fake data
- no fake integrations
- no invented scores
- no invented leads
- separate facts, analysis and predictions
- preserve component identity
- audit related files together
- build one capability, test it, fix it, then continue
