# Customer Intelligence

Authorised connection layer.

Connection wizard targets:
- website/domain
- Google Business
- Search Console
- Analytics
- social media
- WhatsApp Business
- CRM
- CMS
- email
- advertising
- GitHub
- AI providers

Never mark a provider connected until real authorization/verification exists.
