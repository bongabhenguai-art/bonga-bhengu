# Brand-to-Market Wizard

1. Brand Foundation
2. Name + Tagline Intelligence
3. Visual Identity
4. Website Architecture + Copy
5. Lead Magnet + Core Offer
6. Launch Command Center
7. First-Customer Engine
8. Measurement + Improvement

Existing businesses must be audited first so the wizard works from evidence instead of assumptions.
