# Fukulisane — Public Visibility MVP

A production-oriented first customer loop: **Business name → public research → visibility evidence → score → free proof → connect/choose package**.

## Deploy to Netlify
1. Push this folder to GitHub.
2. In Netlify: Add new project → Import existing project → select the repo. Netlify detects the Vite build; the included `netlify.toml` sets build/publish/function configuration.
3. Add `OPENAI_API_KEY` as a Netlify environment variable (Functions scope). Optional: `OPENAI_MODEL`.
4. Deploy. Netlify production deploys serve the production version at the site's primary domain.
5. Add your real domain under Domain management → Production domains.

## Important
The app deliberately returns an explicit unavailable state when live research is not configured. It does not fabricate public scores. The free result is based on public research; connected/paid workflows are the next production phase.
