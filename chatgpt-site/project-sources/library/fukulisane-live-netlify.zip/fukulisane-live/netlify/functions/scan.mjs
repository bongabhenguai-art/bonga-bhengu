export default async (req) => {
  if(req.method!=='POST') return new Response(JSON.stringify({error:'POST required'}),{status:405,headers:{'content-type':'application/json'}});
  try{
    const {business,location=''}=await req.json();
    if(!business) throw new Error('Business name is required.');
    if(!process.env.OPENAI_API_KEY) return new Response(JSON.stringify({error:'Live research is not configured yet. Add OPENAI_API_KEY to Netlify environment variables, then redeploy.'}),{status:503,headers:{'content-type':'application/json'}});
    const prompt=`Research the public online visibility of this business: ${business}${location?` in ${location}`:''}. Use only publicly accessible evidence. Do not invent facts. Return JSON only with keys: name, score (integer 0-100), summary, pillars (array of 6 arrays [name, score, status]), strengths (3 strings), gaps (3 strings), evidence (up to 6 strings). Pillars must be Website, Search, Social, Content, Reputation, Local. Score must be a transparent evidence-based estimate, and evidence should identify what was actually found or not found. If a source cannot be verified, say so.`;
    const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5.6',tools:[{type:'web_search_preview'}],input:prompt})});
    if(!response.ok){const t=await response.text(); throw new Error(`AI research failed: ${t.slice(0,240)}`)}
    const data=await response.json(); const text=data.output_text||''; const match=text.match(/\{[\s\S]*\}/); if(!match) throw new Error('Research returned an invalid result.');
    const result=JSON.parse(match[0]); result.name=result.name||business; return new Response(JSON.stringify(result),{status:200,headers:{'content-type':'application/json','cache-control':'no-store'}});
  }catch(e){return new Response(JSON.stringify({error:e.message||'Scan failed'}),{status:500,headers:{'content-type':'application/json'}})}
};
