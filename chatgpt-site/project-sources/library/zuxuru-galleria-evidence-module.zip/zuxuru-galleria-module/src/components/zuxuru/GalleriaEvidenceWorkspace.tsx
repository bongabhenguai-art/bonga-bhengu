import React, { useMemo, useState } from 'react';
import {
  answerQuestion,
  evidenceSummary,
  galleriaWorkspace,
  type Evidence,
  type EvidenceStatus,
  type GalleriaWorkspace,
} from '../../lib/zuxuru/galleria-evidence';

const statusLabels: Record<EvidenceStatus, string> = {
  verified: 'Verified',
  observed: 'Observed',
  'customer-provided': 'Customer-provided',
  likely: 'Likely',
  contradicted: 'Contradicted',
  unknown: 'Unknown',
  missing: 'Missing',
  stale: 'Stale',
  unverified: 'Unverified',
};

const seedEvidence: Evidence[] = [
  {
    id: 'galleria-visitor-claim',
    subject: 'Visitor volume',
    claim: 'A visitor-volume figure has been discussed and requires definition and verification.',
    source: 'Meeting preparation / historical discussion',
    sourceType: 'meeting',
    capturedAt: new Date().toISOString(),
    status: 'unverified',
    confidence: null,
    notes: 'Do not treat the number as a verified metric until the measurement method is understood.',
  },
];

export function GalleriaEvidenceWorkspace() {
  const [workspace, setWorkspace] = useState<GalleriaWorkspace>({
    ...galleriaWorkspace,
    evidence: seedEvidence,
  });
  const [selectedQuestion, setSelectedQuestion] = useState(workspace.questions[0]?.id ?? '');
  const [answer, setAnswer] = useState('');
  const summary = useMemo(() => evidenceSummary(workspace), [workspace]);

  function saveAnswer() {
    if (!selectedQuestion || !answer.trim()) return;
    setWorkspace((current) =>
      answerQuestion(current, selectedQuestion, answer.trim(), [], 'answered'),
    );
    setAnswer('');
  }

  return (
    <section className="space-y-6 p-6">
      <header>
        <p className="text-sm font-medium text-muted-foreground">Mall Intelligence / Evidence Workspace</p>
        <h1 className="text-2xl font-semibold">Galleria Mall</h1>
        <p className="mt-1 text-sm text-muted-foreground">{workspace.location}</p>
      </header>

      <div className="grid gap-3 md:grid-cols-4">
        <Metric label="Evidence items" value={workspace.evidence.length} />
        <Metric label="Verified" value={summary.verified ?? 0} />
        <Metric label="Unverified" value={summary.unverified ?? 0} />
        <Metric label="Open questions" value={workspace.questions.filter((q) => q.status === 'open').length} />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-xl border bg-card p-5">
          <h2 className="font-semibold">Evidence register</h2>
          <div className="mt-4 space-y-3">
            {workspace.evidence.map((item) => (
              <article key={item.id} className="rounded-lg border p-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-medium">{item.subject}</h3>
                    <p className="mt-1 text-sm">{item.claim}</p>
                    <p className="mt-2 text-xs text-muted-foreground">Source: {item.source}</p>
                  </div>
                  <span className="rounded-full border px-2 py-1 text-xs">
                    {statusLabels[item.status]}
                  </span>
                </div>
                {item.notes && <p className="mt-3 text-xs text-muted-foreground">{item.notes}</p>}
              </article>
            ))}
          </div>
        </div>

        <div className="rounded-xl border bg-card p-5">
          <h2 className="font-semibold">Meeting questions</h2>
          <div className="mt-4 space-y-3">
            {workspace.questions.map((question) => (
              <button
                key={question.id}
                type="button"
                onClick={() => setSelectedQuestion(question.id)}
                className={`w-full rounded-lg border p-3 text-left ${selectedQuestion === question.id ? 'ring-2' : ''}`}
              >
                <div className="text-sm font-medium">{question.question}</div>
                <div className="mt-1 text-xs text-muted-foreground">{question.reason}</div>
                <div className="mt-2 text-xs">Status: {question.status}</div>
              </button>
            ))}
          </div>

          <div className="mt-5">
            <label className="text-sm font-medium">Meeting note / answer</label>
            <textarea
              value={answer}
              onChange={(event) => setAnswer(event.target.value)}
              className="mt-2 min-h-28 w-full rounded-lg border bg-background p-3 text-sm"
              placeholder="Record what Galleria actually says. Do not convert a statement into verified evidence automatically."
            />
            <button
              type="button"
              onClick={saveAnswer}
              className="mt-3 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Save meeting evidence
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
