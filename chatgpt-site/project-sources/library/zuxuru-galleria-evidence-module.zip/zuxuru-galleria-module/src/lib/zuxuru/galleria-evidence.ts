export type EvidenceStatus =
  | 'verified'
  | 'observed'
  | 'customer-provided'
  | 'likely'
  | 'contradicted'
  | 'unknown'
  | 'missing'
  | 'stale'
  | 'unverified';

export type Evidence = {
  id: string;
  subject: string;
  claim: string;
  source: string;
  sourceType: 'public' | 'customer' | 'connected' | 'meeting';
  capturedAt: string;
  status: EvidenceStatus;
  confidence: number | null;
  notes?: string;
};

export type GalleriaPerson = {
  name: string;
  role: string;
  source: string;
  status: EvidenceStatus;
};

export type MeetingQuestion = {
  id: string;
  question: string;
  reason: string;
  answer?: string;
  evidenceIds: string[];
  status: 'open' | 'answered' | 'needs-verification';
};

export type GalleriaWorkspace = {
  businessName: 'Galleria Mall';
  location: string;
  entityType: 'mall';
  evidence: Evidence[];
  contacts: GalleriaPerson[];
  questions: MeetingQuestion[];
};

export const galleriaWorkspace: GalleriaWorkspace = {
  businessName: 'Galleria Mall',
  location: 'Amanzimtoti, KwaZulu-Natal, South Africa',
  entityType: 'mall',
  evidence: [],
  contacts: [],
  questions: [
    {
      id: 'visitor-measurement',
      question: 'How is the visitor figure measured and defined?',
      reason: 'Any visitor-volume claim must be understood before it is treated as verified evidence.',
      evidenceIds: [],
      status: 'open',
    },
    {
      id: 'marketing-measurement',
      question: 'Which marketing outcomes does the team currently measure?',
      reason: 'Zuxuru should understand the team’s existing measurement model before proposing changes.',
      evidenceIds: [],
      status: 'open',
    },
    {
      id: 'tenant-intelligence',
      question: 'What tenant information and performance information is available to the marketing team?',
      reason: 'This establishes what the Mall intelligence layer could legitimately connect to.',
      evidenceIds: [],
      status: 'open',
    },
    {
      id: 'system-access',
      question: 'Which internal systems could be connected to Zuxuru if Galleria authorizes access?',
      reason: 'CIA must use explicit authorization and should never assume access.',
      evidenceIds: [],
      status: 'open',
    },
  ],
};

export function addEvidence(
  workspace: GalleriaWorkspace,
  evidence: Evidence,
): GalleriaWorkspace {
  return { ...workspace, evidence: [...workspace.evidence, evidence] };
}

export function reconcileClaim(
  workspace: GalleriaWorkspace,
  evidenceId: string,
  status: EvidenceStatus,
  notes?: string,
): GalleriaWorkspace {
  return {
    ...workspace,
    evidence: workspace.evidence.map((item) =>
      item.id === evidenceId ? { ...item, status, notes: notes ?? item.notes } : item,
    ),
  };
}

export function answerQuestion(
  workspace: GalleriaWorkspace,
  questionId: string,
  answer: string,
  evidenceIds: string[],
  status: MeetingQuestion['status'] = 'answered',
): GalleriaWorkspace {
  return {
    ...workspace,
    questions: workspace.questions.map((q) =>
      q.id === questionId ? { ...q, answer, evidenceIds, status } : q,
    ),
  };
}

export function evidenceSummary(workspace: GalleriaWorkspace) {
  return workspace.evidence.reduce<Record<string, number>>((summary, item) => {
    summary[item.status] = (summary[item.status] ?? 0) + 1;
    return summary;
  }, {});
}
