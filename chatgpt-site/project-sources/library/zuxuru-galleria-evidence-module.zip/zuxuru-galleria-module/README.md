# Zuxuru — Galleria Evidence & Meeting Module

This module implements the Galleria-specific part of the Zuxuru architecture discussed in the historical source material:

- Galleria is treated as a mall/centre entity.
- Evidence is separate from claims.
- Customer-provided statements are explicitly labelled.
- Unknown/unverified is not converted into zero.
- Meeting questions remain open until answered.
- Evidence can later be reconciled with public and authorized connected sources.
- CIA authorization is not assumed.
- Jarvis can sit above this workspace as an evidence/meeting assistant.

## Intended integration

Target repository: `bongabhenguexceed-pixel/zuxuru`

Target stack: Vite + React + Tailwind + Hono + Prisma.

Suggested integration:

1. Copy `src/lib/zuxuru/galleria-evidence.ts` into the existing Zuxuru library.
2. Copy `src/components/zuxuru/GalleriaEvidenceWorkspace.tsx` into the dashboard components.
3. Add the workspace to the existing navigation/router.
4. Replace the seed evidence with records produced by the existing Investigation/Evidence engines.
5. Persist evidence/questions through the existing Business DB/Prisma layer.
6. Connect Jarvis to the same workspace through the existing AI execution layer.
7. Add authorized CIA sources only after Galleria approval.

This module deliberately does **not** invent Galleria metrics, tenant problems, marketing weaknesses, or package requirements.
