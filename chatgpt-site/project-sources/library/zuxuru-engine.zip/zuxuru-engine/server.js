import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { URL } from 'node:url';
import { identityCandidates, investigate, graph } from './src/engine.js';

const PORT=process.env.PORT||3000;
const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*'});res.end(JSON.stringify(data));};
const body=async req=>{let b='';for await(const c of req)b+=c;return b?JSON.parse(b):{};};

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,`http://${req.headers.host}`);
    if(req.method==='GET'&&u.pathname==='/api/health') return json(res,200,{ok:true,engine:'Zuxuru Investigation Engine',version:'0.1.0',time:new Date().toISOString()});
    if(req.method==='POST'&&u.pathname==='/api/identity-candidates') {const b=await body(req);return json(res,200,{candidates:identityCandidates(b.name||'Unnamed Business',b)});}
    if(req.method==='POST'&&u.pathname==='/api/investigate') {const b=await body(req);if(!b.name)return json(res,400,{error:'Business name is required'});const r=investigate(b);return json(res,200,{...r,graph:graph(r)});}
    if(req.method==='GET') {let p=u.pathname==='/'?'/index.html':u.pathname;const data=await readFile(new URL(`./public${p}`,import.meta.url));const ext=p.split('.').pop();const ct={html:'text/html',js:'text/javascript',css:'text/css',svg:'image/svg+xml'}[ext]||'text/plain';res.writeHead(200,{'content-type':ct});return res.end(data);}
    json(res,404,{error:'Not found'});
  }catch(e){json(res,500,{error:e.message});}
});
server.listen(PORT,()=>console.log(`Zuxuru engine running on http://localhost:${PORT}`));
