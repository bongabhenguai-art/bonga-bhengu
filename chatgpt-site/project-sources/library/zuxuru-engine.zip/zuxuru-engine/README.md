# Zuxuru Investigation + Opportunity Engine

A runnable foundation for the Zuxuru/Fukulisane Business Growth Operating System. It implements the core engine loop locally:

**NAME → IDENTITY → EVIDENCE → CUSTOMERS → ASSETS → OPPORTUNITIES → DIAGNOSIS → SOLUTION → REPLAY**

## Run

Requires Node.js 20+.

```bash
npm start
```

Open `http://localhost:3000`.

## Current functioning components

- Business-name intake
- Up to 5 identity candidate cards
- Owner confirmation gate
- Evidence records with finding, reason, observation, source, confidence, impact and action
- Customer-group inference explicitly marked as potential/unverified
- Customer needs map
- Asset registry
- Opportunity graph
- Opportunity-to-offer hooks
- Root-cause/diagnosis layer
- Solution generation
- Investigation replay
- JSON API endpoints:
  - `GET /api/health`
  - `POST /api/identity-candidates`
  - `POST /api/investigate`

## Production connector boundary

The engine deliberately does not fabricate web evidence. To make live Investigation AI operational, add a public-source search adapter (search engine/business directories/social/review sources) and pass returned pages through an evidence normalizer before they enter the graph.

Recommended production stack:
- Next.js App Router frontend
- Vercel deployment
- Durable workflow orchestration for investigation runs, retries and approvals
- Postgres/Supabase for businesses, evidence, graph, assets, opportunities, offers, leads and audit logs
- AI agent/tool layer for dynamic investigation planning
- Search/business/review/social connectors
- Human approval for identity confirmation and outbound actions

The core domain engine in `src/engine.js` is intentionally provider-neutral so existing work can be connected rather than discarded.
