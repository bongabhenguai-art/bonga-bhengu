export const STATUS = ['discovered','verified','qualified','offer_created','proposed','negotiating','won','active','measured','renewed','lost','learned'];

function now(){ return new Date().toISOString(); }
function slug(s){ return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
function uniq(arr){ return [...new Set(arr.filter(Boolean))]; }
function confidence(score){ return score>=0.8?'High':score>=0.55?'Medium':'Low'; }

export function identityCandidates(name, supplied={}){
  const base = {
    name, location:supplied.location||'Unknown', category:supplied.category||'Unknown', website:supplied.website||'', phone:supplied.phone||'', source:'user-provided identity seed', checkedAt:now()
  };
  return [
    {...base, id:`${slug(name)}-1`, matchReason:'Exact name match from the investigation seed', identityConfidence:supplied.website||supplied.phone?'High':'Medium'},
    {...base, id:`${slug(name)}-2`, name:`${name} Official`, matchReason:'Common official/trading-name variant to verify', identityConfidence:'Low'},
    {...base, id:`${slug(name)}-3`, name:`${name} ${supplied.location||'Local'}`, matchReason:'Name + location variant to verify', identityConfidence:'Low'},
    {...base, id:`${slug(name)}-4`, name:`${name} Group`, matchReason:'Possible parent/network relationship; only relevant if multiple locations exist', identityConfidence:'Low'},
    {...base, id:`${slug(name)}-5`, name:`${name} Services`, matchReason:'Possible category/trading variant to verify', identityConfidence:'Low'}
  ];
}

export function investigate(seed){
  const business={
    id:`biz_${slug(seed.name)}`,
    name:seed.name,
    location:seed.location||'Unknown',
    category:seed.category||'Unknown',
    website:seed.website||null,
    phone:seed.phone||null,
    identityStatus:'awaiting_confirmation',
    checkedAt:now()
  };
  const evidence=[];
  const add=(finding,why,observation,source='User-provided seed',type='Observed fact',conf='Medium',impact='Medium',action='Verify')=>evidence.push({id:`ev_${evidence.length+1}`,finding,why,evidence:observation,source,sourceType:'seed',checkedAt:now(),confidence:conf,interpretation:type,impact,action});
  add('Business name is available','The name is the starting key for entity discovery',`Seed entered: ${seed.name}`,'User input','Observed fact','High','High','Confirm the correct business');
  if(seed.location) add('Location is available','Location disambiguates businesses with similar names',seed.location,'User input','Observed fact','High','High','Use location in identity matching');
  if(seed.website) add('Website is available','A domain is a strong identity signal',seed.website,'User input','Observed fact','High','High','Verify domain ownership/association');
  if(seed.phone) add('Public phone is available','Phone is a strong cross-platform identity signal',seed.phone,'User input','Observed fact','High','High','Compare across public listings');

  const digital=[
    {name:'Website',state:seed.website?'Present':'Unknown',next:'Check domain, clarity, services, CTA and conversion path'},
    {name:'Business listings',state:'Unknown',next:'Search local discovery platforms and compare identity fields'},
    {name:'Social profiles',state:'Unknown',next:'Find official profiles and assess activity/consistency'},
    {name:'Reviews',state:'Unknown',next:'Find reputation evidence, recurring praise, complaints and questions'},
    {name:'Search visibility',state:'Unknown',next:'Run exact-name, service, location and problem-intent searches'}
  ];

  const groups = inferCustomerGroups(seed);
  const needs = inferNeeds(seed, groups);
  const assets = inferAssets(seed);
  const opportunities = buildOpportunities(business,groups,needs,assets);
  const diagnosis = diagnose(seed,{digital,groups,needs,assets,opportunities});
  const solutions = buildSolutions(diagnosis,opportunities);
  return {business,evidence,digital,customers:{groups,needs,intentStages:['Problem awareness','Solution research','Business discovery','Evaluation','Buying intent','Existing customer']},assets,opportunities,diagnosis,solutions,investigationReplay:buildReplay(seed,{evidence,digital,groups,needs,assets,opportunities,diagnosis,solutions})};
}

function inferCustomerGroups(seed){
  const c=(seed.category||'').toLowerCase();
  const map={
    gym:['Students','Office workers','Parents','Athletes','Beginners','Professionals'],
    fitness:['Students','Office workers','Parents','Athletes','Beginners','Professionals'],
    restaurant:['Office workers','Families','Local residents','Visitors','Event customers'],
    salon:['Professionals','Students','Parents','Event customers','Local residents'],
    hotel:['Business travellers','Tourists','Event guests','Local visitors','Corporate clients'],
    taxi:['Office workers','Students','Tourists','Families','Airport travellers'],
    school:['Parents','Students','Teachers','Local families','Education service providers'],
    clinic:['Patients','Families','Professionals','Older adults','Caregivers']
  };
  const key=Object.keys(map).find(k=>c.includes(k));
  return (map[key]||['Local customers','Returning customers','New prospects']).map((name,i)=>({name,status:i<2?'Potential':'Unverified',confidence:i<2?'Medium':'Low',basis:`Category signal: ${seed.category||'Unknown'}`}));
}
function inferNeeds(seed,groups){
  return groups.slice(0,6).flatMap(g=>{
    const needs = g.name.includes('Students')?['transport','food','education','clothing']:
      g.name.includes('Office')?['lunch','transport','clothing','financial services']:
      g.name.includes('Parents')?['family services','children activities','healthcare']:
      g.name.includes('Athletes')?['equipment','nutrition','physiotherapy']:
      ['convenience','information','relevant offers'];
    return needs.map(n=>({customerGroup:g.name,need:n,status:'Potential',confidence:'Low'}));
  });
}
function inferAssets(seed){
  const c=(seed.category||'').toLowerCase();
  const common=[
    ['Customer audience','Audience Hub','Recurring customer attention can be a commercial asset; volume must be measured.'],
    ['Brand presence','Brand','Name, reputation, visuals and public presence can support trust and discovery.'],
    ['Content/community','Distribution','Existing content, community activity or events may create distribution inventory.'],
    ['Partnership surface','Relationship','Customers and complementary businesses may create mutual-value relationships.']
  ];
  if(c.includes('gym')||c.includes('fitness')) common.push(['Digital screens','Advertising inventory','Potential screen advertising asset; actual inventory requires screen count, slot length and operating schedule.']);
  if(c.includes('hotel')) common.push(['Rooms/events','Sponsorship / partnership inventory','Potential corporate and event partnership surface.']);
  if(c.includes('restaurant')) common.push(['Tables / events','Promotion inventory','Potential partner promotion or event inventory.']);
  return common.map(([name,type,desc],i)=>({id:`asset_${i+1}`,name,type,description:desc,status:'Potential',evidence:'Requires live/public or authorized verification',capacity:'Unknown',monetization:'To be calculated after measurement'}));
}
function buildOpportunities(business,groups,needs,assets){
  const out=[];
  for(const a of assets){
    if(a.type==='Advertising inventory') out.push({id:'opp_screen_ads',type:'Asset monetization',title:'Digital advertising inventory',status:'discovered',value:'To be priced',confidence:'Medium',why:'Potential audience-facing inventory exists',evidence:a.description,hook:'Reach a relevant local audience through your business environment.',offer:'Monthly advertising package',next:'Measure screens, operating hours, slot length and available rotations.'});
    if(a.type==='Audience Hub') out.push({id:'opp_partner',type:'Partner',title:'Customer ecosystem partnerships',status:'discovered',value:'To be qualified',confidence:'Low',why:'Recurring customer groups may have adjacent needs',evidence:'Customer groups inferred from category; requires validation',hook:'Put a useful offer in front of a relevant customer community.',offer:'Partner promotion / referral package',next:'Identify complementary businesses and validate demand.'});
  }
  const uniqueNeeds=uniq(needs.map(n=>n.need)).slice(0,5);
  for(const n of uniqueNeeds) out.push({id:`opp_need_${slug(n)}`,type:'Potential business lead',title:`Businesses serving ${n}`,status:'discovered',value:'To be qualified',confidence:'Low',why:`Customer ecosystem signal indicates a possible ${n} need`,evidence:'AI inference; not a verified customer fact',hook:`Connect a relevant ${n} provider with this audience.`,offer:'Cross-promotion or advertising proposal',next:'Find and verify local businesses that serve this need.'});
  return out;
}
function diagnose(seed,data){
  const issues=[];
  if(!seed.website) issues.push({symptom:'No website supplied',problem:'Digital conversion path may be incomplete',why:['Customers may need more information before acting','A website can provide services, proof, FAQs and CTAs'],rootCause:'Unknown until live investigation',confidence:'Low'});
  issues.push({symptom:'Customer groups are not yet verified',problem:'Opportunity targeting is uncertain',why:['Category alone cannot prove actual customer mix'],rootCause:'Missing public/authorized customer evidence',confidence:'Medium'});
  issues.push({symptom:'Assets are not measured',problem:'Monetization opportunities cannot be priced accurately',why:['Inventory requires capacity and usage data'],rootCause:'No measured asset/capacity data connected',confidence:'High'});
  return {summary:`Initial diagnosis for ${seed.name}: investigation is seeded but not yet live-verified.`,issues};
}
function buildSolutions(diagnosis,opportunities){
  return diagnosis.issues.map((x,i)=>({id:`sol_${i+1}`,title:x.rootCause==='No measured asset/capacity data connected'?'Measure and package commercial inventory':'Evidence-led visibility and customer discovery',problem:x.problem,rootCause:x.rootCause,steps:x.rootCause==='No measured asset/capacity data connected'?['Register asset','Measure capacity','Calculate inventory','Create offer','Find matching businesses','Track delivery']:['Verify business identity','Run public discovery searches','Capture evidence','Validate customer groups','Map opportunities','Create action package']}));
}
function buildReplay(seed,d){
  return [
    `1. Business name entered: ${seed.name}`,
    '2. Identity stage created to prevent same-name collisions.',
    '3. Digital footprint investigation plan generated.',
    `4. Customer groups inferred from category (${seed.category||'unknown'}) and explicitly marked as unverified/potential.`,
    '5. Customer needs mapped as hypotheses, not facts.',
    '6. Asset registry generated with measurement requirements.',
    `7. Opportunity graph generated with ${d.opportunities.length} initial opportunity nodes.`,
    `8. Diagnosis created with ${d.diagnosis.issues.length} evidence gaps/root-cause candidates.`,
    `9. ${d.solutions.length} solution packages generated.`,
    '10. Next live investigation step: public-source discovery and evidence capture.'
  ];
}

export function graph(result){
  const nodes=[{id:result.business.id,label:result.business.name,type:'business'}];
  const edges=[];
  for(const g of result.customers.groups){const id=`cust_${slug(g.name)}`;nodes.push({id,label:g.name,type:'customer_group'});edges.push({from:result.business.id,to:id,type:'has_customer_group'});}
  for(const a of result.assets){nodes.push({id:a.id,label:a.name,type:'asset'});edges.push({from:result.business.id,to:a.id,type:'owns_or_may_own'});}
  for(const o of result.opportunities){nodes.push({id:o.id,label:o.title,type:'opportunity'});edges.push({from:result.business.id,to:o.id,type:'creates'});}
  return {nodes,edges};
}
