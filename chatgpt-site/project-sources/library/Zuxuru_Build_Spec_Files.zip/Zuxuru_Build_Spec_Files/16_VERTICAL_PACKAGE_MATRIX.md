# ZUXURU VERTICAL PACKAGE MATRIX

| Vertical | Entry | Intelligence | Delivery | Result |
|---|---|---|---|---|
| Ordinary Company | Public Score | Visibility + Growth | CIA + Studio + Builder | Growth improvement |
| Mall | Mall discovery | Tenant intelligence | Tenant programme + Studio | Tenant/Mall performance |
| Business Tree | Parent discovery | Group + branch intelligence | Central + branch execution | Network improvement |
| Fashion | Designer/brand profile | Brand/product/lead intelligence | Studio + Builder + campaigns | Sales/brand growth |
| Enterprise | Custom discovery | Full intelligence | Custom CIA/agents/Builder/Studio | Enterprise transformation |

## Common commercial flow

ENTRY
→ SCORE
→ GAP
→ OPPORTUNITY
→ PACKAGE
→ APPROVAL
→ PROJECT
→ DELIVERY
→ MEASUREMENT
→ NEXT PACKAGE/OPPORTUNITY

## Package assembly

The package engine chooses modules according to evidence.

Example:

Fashion designer with weak website but strong Instagram:
- Brand positioning
- Website Builder
- Product catalogue
- Studio content
- Lead capture

Mall with 300 tenants:
- Mall intelligence
- Tenant discovery
- Tenant scores
- Group opportunities
- Tenant campaigns
- Mall Studio
- Analytics

Multi-branch company:
- Business Tree
- Parent dashboard
- Branch scores
- Group campaigns
- branch-level execution

Ordinary local company:
- Visibility Foundation
- AI Visibility Operations
- Brand & Growth Operations
