# ZUXURU PACKAGE ARCHITECTURE

## Package 0 — Public Visibility Score

Audience:
Any company, brand, mall tenant, designer or organisation.

Includes:
- public visibility investigation
- public score
- key findings
- top gaps
- opportunity preview

Purpose:
Convert unknown businesses into qualified prospects.

## Package 1 — Visibility Foundation

Historical working price: R1,999/month.

Includes:
- public visibility investigation
- visibility score
- gap & opportunity report
- platform setup guidance
- account connection
- monthly report

Best for:
Businesses needing a digital foundation.

## Package 2 — AI Visibility Operations

Historical working price: R3,999/month.

Includes Package 1 plus:
- AI content creation
- AI post scheduling
- multi-platform publishing
- performance monitoring
- monthly growth report

Best for:
Businesses needing continuous visibility operations.

## Package 3 — AI Brand & Growth Operations

Historical working price: R6,999/month.

Includes Package 2 plus:
- brand strategy
- positioning
- AI marketing campaigns
- lead-generation workflows
- advanced analytics
- dedicated success management

Best for:
Businesses wanting an ongoing growth operating system.

## Package 4 — Enterprise / Custom

Price:
Custom; do not invent a fixed price before scope/cost validation.

Capabilities:
- Business Tree
- multi-branch intelligence
- Mall/centre-to-tenant programmes
- enterprise CIA
- custom Builder Website/app
- advanced Studio
- custom integrations
- governance
- permissions
- reporting
- enterprise analytics
- custom agents
- custom workflows

## Vertical packaging

Packages are not limited to one generic feature list.

The package engine can assemble a proposal from modules:

Visibility
Brand
Website
Content
Studio
Leads
Campaigns
Sales
Analytics
CIA
Business Tree
Mall
Fashion
Builder
Enterprise

## Pricing note

Previous working material also contained a pilot pricing version:
- R999
- R2,499
- R4,999

These should be treated as historical/pilot alternatives, not silently mixed with the R1,999/R3,999/R6,999 structure.

Final prices should be validated against onboarding cost, AI/API cost, infrastructure, human service, retention, CAC and target gross margin.
