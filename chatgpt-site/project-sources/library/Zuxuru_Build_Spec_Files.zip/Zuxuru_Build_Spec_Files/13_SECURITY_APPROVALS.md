# ZUXURU SECURITY AND APPROVALS

## Principles

1. Least privilege.
2. Connector credentials never enter prompts.
3. Every write has an actor.
4. Every important write has an approval state.
5. Every action is auditable.
6. External publishing is never silently assumed.
7. Destructive actions require explicit confirmation.

## Action levels

GREEN
- read public information
- calculate score
- analyse existing content

YELLOW
- create drafts
- update non-critical profile data
- schedule content
- create website draft
- create campaign draft

RED
- publish externally
- send customer messages
- spend money
- delete data
- disconnect important integrations
- deploy production systems

## Audit event

- actor
- actor_type
- action
- target
- before
- after
- approval_id
- timestamp
- result
- error

## Agent permissions

Every agent has:
- allowed tools
- allowed connectors
- allowed businesses
- allowed action levels

Agents cannot grant themselves permissions.
