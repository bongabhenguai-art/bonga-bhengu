# ZUXURU BUILDER WEBSITE ENGINE

## Purpose

Builder creates and improves business websites inside the Zuxuru workflow.

## Detection

1. Find existing website.
2. Inspect structure and public content.
3. Identify brand/business information.
4. Identify conversion path.
5. Identify technical gaps.
6. Produce website score.

## Blueprint

Website Blueprint contains:
- pages
- navigation
- sections
- copy
- images
- CTAs
- forms
- SEO
- analytics
- tracking
- integrations

## Build lifecycle

DISCOVER
→ BLUEPRINT
→ CONTENT
→ DESIGN
→ BUILD
→ TEST
→ QA
→ APPROVE
→ DEPLOY
→ MEASURE
→ IMPROVE

## Controlled generation

Builder must:
- generate code from known requirements
- validate routes
- validate forms
- test responsive layouts
- check links
- check metadata
- check analytics
- check accessibility
- create deployable version
- retain previous version for rollback

## Business integration

Builder receives intelligence from:
- Business Profile
- Visibility Score
- Brand Engine
- Lead Engine
- Offer Engine
- Studio

Therefore the website is not just a brochure. It is a growth asset.
