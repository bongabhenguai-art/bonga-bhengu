# ZUXURU MALL SYSTEM

## Purpose

A Mall/Centre is a parent business environment containing multiple tenant businesses.

Zuxuru treats the Mall as an ecosystem rather than simply another company.

## Data model

Mall
- identity
- physical address
- website
- public directories
- social profiles
- management information
- operating information

Tenant
- business identity
- category
- location
- unit/shop
- public profiles
- website
- social accounts
- contact details
- owner/manager when discoverable
- visibility score

## Discovery workflow

Mall
→ public tenant directory
→ tenant discovery
→ identity matching
→ duplicate detection
→ tenant profile
→ public visibility investigation
→ tenant score

## Mall dashboard

Sections:
- Mall Overview
- Tenant Directory
- Tenant Coverage
- Tenant Visibility
- Tenant Opportunities
- Campaigns
- Centre Content
- Tenant Engagement
- Group Analytics

## Tenant intelligence

For each tenant:
- visibility score
- profile completeness
- website
- Google/maps presence
- social presence
- content activity
- reviews/reputation signals
- conversion assets
- lead capture
- contactability
- growth blockage
- recommended package

## Commercial model

Mall can purchase:
1. Mall Intelligence
2. Tenant Visibility Programme
3. Tenant Growth Programme
4. Mall Content/Studio Programme
5. Custom Enterprise Programme

Mall management may sponsor or subsidise tenant packages.

## Permission

Zuxuru must distinguish:
- information visible publicly
- information supplied by Mall
- information supplied by tenant
- information requiring tenant consent
- information requiring Mall authorisation

Do not assume Mall authority gives permission to edit tenant-owned accounts.

## Mall growth loop

Discover tenants
→ score tenants
→ identify weak areas
→ group common problems
→ generate campaign/package
→ Mall approves
→ tenant participation/approval
→ CIA connects
→ Studio/Builder executes
→ measure tenant + Mall results
→ next campaign.
