# ZUXURU ORDINARY COMPANY / FREE ENTRY SYSTEM

## Free/public entry

Any company can enter its business name and receive a Public Visibility Score.

No connection is required for the initial public scan.

## Public investigation

Find:
- website
- maps/local profile
- social profiles
- directory listings
- public contact information
- public content
- reviews/reputation signals
- obvious gaps
- inconsistent information

## Score

The score should be evidence-based.

Example dimensions:
- identity consistency
- discoverability
- profile completeness
- website presence
- content activity
- trust signals
- conversion readiness
- contactability

Never invent missing evidence.

## Free experience

Free/public:
- basic score
- public findings
- top gaps
- limited opportunity explanation

Paid/connected:
- deep platform analysis
- action plan
- AI content
- lead workflows
- publishing
- Studio
- Builder
- analytics
- continuous monitoring

## Company lifecycle

PUBLIC
→ IDENTIFIED
→ VERIFIED
→ CONNECTED
→ DIAGNOSED
→ OPPORTUNITY
→ PACKAGE
→ APPROVED
→ PROJECT
→ EXECUTION
→ RESULT
→ RETENTION/EXPANSION

## Business Tree rule

Only use Business Tree when multiple identifiable locations/branches exist.

Single-location company:
Business Profile → normal workflow.

Multi-location:
Parent/Head Office → branches → branch profiles → group insights.

## Lead generation

Every public investigation can create:
- business lead
- opportunity
- recommended next action
- recommended package

The public score is therefore both a product feature and a lead-generation mechanism.
