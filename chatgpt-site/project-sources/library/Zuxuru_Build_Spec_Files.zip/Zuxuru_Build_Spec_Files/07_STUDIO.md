# ZUXURU STUDIO

## Purpose

Studio is the production and delivery environment inside Zuxuru.

It is not a separate product or login.

## Capture

Phone camera:
- photo
- video
- audio

Upload:
- images
- video
- audio
- documents

## Media pipeline

CAPTURE
→ UPLOAD
→ TRANSCRIBE
→ ANALYSE
→ EDIT
→ GENERATE
→ REPURPOSE
→ APPROVE
→ PUBLISH
→ MEASURE

## AI capabilities

- transcription
- captions
- summaries
- clips
- hooks
- titles
- descriptions
- social versions
- website versions
- ad variations
- SEO text
- image generation
- video assistance
- content calendar

## Content object

ContentAsset:
- id
- owner
- business
- source
- media_type
- duration
- transcript
- variants
- campaign
- status
- approval
- publication records
- performance

## Publishing

One source asset can produce:
- Instagram version
- Facebook version
- TikTok version
- LinkedIn version
- YouTube version
- website version
- WhatsApp version

Publishing always respects platform connection and approval.
