# JARVIS AI — ZUXURU ADAPTATION

## Source architecture used

This specification uses the current public `omnigentx/jarvis` repository as the primary Jarvis reference.

The repository describes:
- a root Jarvis agent
- specialist agents
- MCP-first tools
- dynamic agent spawning
- durable memory
- a Vue/Vite dashboard
- FastAPI backend
- SQLite runtime state
- skills loaded at runtime
- team templates
- real-time activity/progress

Reference:
https://github.com/omnigentx/jarvis

## Actual important source files

### backend/agent.py
Purpose:
- Defines the FastAgent application.
- Defines static specialist agents.
- Assigns skills and MCP servers to agents.
- Configures memory capability.
- Defines the root Jarvis runtime.
- Supports agent spawning and self-improving tooling.

Zuxuru adaptation:
- Replace generic personal/IOT/music/research specialists with business-growth specialists.
- Keep the agent registration pattern.
- Keep skills and MCP server separation.
- Keep per-agent memory isolation where appropriate.

Zuxuru agents:

JarvisGrowthOrchestrator
BusinessInvestigationAgent
BusinessVerificationAgent
VisibilityScoreAgent
GrowthDiagnosisAgent
OpportunityAgent
HookAgent
OfferAgent
LeadAgent
PersonalizationAgent
CloserAgent
MallAgent
TenantAgent
BusinessTreeAgent
FashionAgent
BrandAgent
ContentAgent
StudioAgent
WebsiteBuilderAgent
SEOAgent
PublishingAgent
AnalyticsAgent
MeasurementAgent
LearningAgent
ConnectionAgent
ApprovalAgent

### backend/server.py
Purpose:
- FastAPI entry point.
- Loads environment/configuration.
- Initializes database.
- Restores configuration.
- Starts runtime services.
- Connects spawn events to progress streaming.

Zuxuru adaptation:
- FastAPI remains the backend entry point.
- Replace Jarvis-specific bootstrapping with Zuxuru configuration.
- Preserve early configuration loading before agent construction.
- Preserve runtime event infrastructure.

### backend/routes/
Purpose:
- HTTP/SSE endpoints.
- Chat.
- Agent activity.
- Approvals.
- Scheduler.
- Notifications.

Zuxuru adaptation:
- Add business, investigation, opportunity, package, project, Studio, Builder, connection and publishing APIs.
- Keep SSE/WebSocket-style activity streaming.

### backend/services/session_service.py
Purpose:
- Session and conversation state.

Zuxuru adaptation:
- Add business_id, organisation_id, project_id and workflow_id to sessions.
- A conversation must understand which business/project it belongs to.

### backend/services/activity_stream.py
Purpose:
- Real-time activity/progress.

Zuxuru adaptation:
- Stream investigation, agent, Studio, Builder and publishing events to the dashboard.

### backend/services/agent_definitions.py
Purpose:
- Stores runtime-created agent definitions.
- Supports create/list/get/update/delete.
- Maintains revision/audit state.

Zuxuru adaptation:
- Store dynamic specialist definitions.
- Add business vertical, permissions, tool allowlist and skill list.

### backend/team_templates/agile_team.yaml
Purpose:
- Defines PM, BA, SA, Dev, Designer, QE, DSO roles.
- PM chooses the team based on task.
- Work is delegated and monitored.

Zuxuru adaptation:
Use this model for large business projects.

Example:
Growth Project:
- PM/Orchestrator
- Business Analyst
- Growth Strategist
- Brand
- Content
- Developer
- Designer
- QA
- Analytics

Website Project:
- PM
- BA
- Solution Architect
- Designer
- Developer
- QA
- SEO
- Deployment

Mall Campaign:
- Mall Agent
- Tenant Intelligence
- Content
- Lead
- Campaign
- Analytics

## What Zuxuru should NOT copy blindly

Do not copy Jarvis's personal-assistant domain agents.

Do not make Zuxuru a desktop assistant.

Do not make every business workflow an autonomous agent.

Use Jarvis as the orchestration/runtime pattern.

Zuxuru remains the business-growth product and domain system.

## Recommended Zuxuru runtime pattern

User request
→ Zuxuru workflow
→ Jarvis Orchestrator
→ plan
→ specialist agents
→ CIA/tools
→ approval if needed
→ execution
→ evidence
→ measurement
→ learning
