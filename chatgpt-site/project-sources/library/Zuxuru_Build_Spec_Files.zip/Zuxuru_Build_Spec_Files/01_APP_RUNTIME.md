# ZUXURU APP RUNTIME

## User journey

1. User enters Zuxuru.
2. User can enter a business/brand name without connecting anything.
3. Zuxuru performs a Public Visibility Investigation.
4. Zuxuru produces:
   - identity
   - public platforms found
   - visibility score
   - missing/weak areas
   - growth opportunities
5. Zuxuru explains why connecting accounts would produce deeper intelligence.
6. User connects platforms through CIA.
7. Zuxuru performs a Connected Investigation.
8. Jarvis selects specialist agents/tools.
9. Zuxuru produces:
   - verified platform state
   - business profile
   - blockage
   - opportunity
   - recommended package
10. User approves package.
11. Zuxuru creates a project.
12. Studio/Builder/CIA execute the work.
13. Zuxuru measures results.
14. Score and evidence update.
15. Learning engine generates the next opportunity.

## Main screens

/public-score
/business
/business/:id
/business/:id/investigation
/business/:id/opportunities
/business/:id/leads
/business/:id/projects
/business/:id/analytics
/business/:id/connections
/business/:id/settings
/mall
/mall/:id
/mall/:id/tenants
/fashion
/fashion/:brand_id
/studio
/builder
/packages
/approvals
/activity
/settings

## Application shell

Left navigation:
- Home
- Businesses
- Mall
- Fashion
- Growth
- Leads
- Studio
- Builder
- Analytics
- Packages
- Connections
- Approvals
- Settings

Top bar:
- Search
- Notifications
- Current business/organisation
- AI/Jarvis activity
- Help

## Real-time behaviour

Long-running work should stream progress:
- Investigation started
- Searching
- Verifying
- Score calculated
- Opportunity detected
- Agent working
- Approval required
- Action executed
- Measurement updated

No fake progress.
