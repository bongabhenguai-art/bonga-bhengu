# ZUXURU API AND WORKFLOW CONTRACTS

## Public

POST /api/public/investigate
GET /api/public/score/:business_id

## Business

POST /api/businesses
GET /api/businesses/:id
GET /api/businesses/:id/score
POST /api/businesses/:id/investigate
GET /api/businesses/:id/opportunities
POST /api/businesses/:id/package
POST /api/businesses/:id/projects

## Mall

POST /api/malls
GET /api/malls/:id
POST /api/malls/:id/discover-tenants
POST /api/malls/:id/score-tenants
GET /api/malls/:id/opportunities

## CIA

GET /api/connections
POST /api/connections/:provider/connect
GET /api/connections/:id/status
POST /api/connections/:id/sync
DELETE /api/connections/:id

## Studio

POST /api/studio/assets
POST /api/studio/transcribe
POST /api/studio/generate
POST /api/studio/edit
POST /api/studio/repurpose
POST /api/studio/publish

## Builder

POST /api/builder/projects
POST /api/builder/projects/:id/blueprint
POST /api/builder/projects/:id/build
POST /api/builder/projects/:id/test
POST /api/builder/projects/:id/deploy
POST /api/builder/projects/:id/rollback

## Growth

POST /api/growth/hooks
POST /api/growth/offers
POST /api/growth/leads
POST /api/growth/personalize
POST /api/growth/close-package
POST /api/growth/measure

## Agent

POST /api/agent/run
GET /api/agent/runs/:id
GET /api/agent/runs/:id/events
POST /api/agent/runs/:id/approve
POST /api/agent/runs/:id/cancel

## Event format

{
  "event_id": "...",
  "type": "investigation.progress",
  "business_id": "...",
  "workflow_id": "...",
  "status": "running",
  "message": "...",
  "timestamp": "..."
}
