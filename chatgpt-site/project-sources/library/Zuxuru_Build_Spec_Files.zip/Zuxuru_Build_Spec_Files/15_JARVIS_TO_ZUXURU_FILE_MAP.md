# JARVIS → ZUXURU FILE MAP

This is the practical translation from the referenced Jarvis repository into Zuxuru.

## Jarvis backend/agent.py
KEEP THE PATTERN:
- central agent registration
- specialist agents
- skills
- MCP servers
- memory
- tool restrictions

CHANGE DOMAIN:
PersonalAgent → BusinessAgent
ResearchAgent → InvestigationAgent
FinanceAgent → Commercial/MarketAgent
Generic root Jarvis → Zuxuru Growth Orchestrator

## Jarvis backend/server.py
KEEP:
- FastAPI application
- early configuration
- database initialisation
- runtime services
- event/socket startup

CHANGE:
- Zuxuru database
- Zuxuru services
- Zuxuru business context

## Jarvis backend/routes/
KEEP:
- route separation
- streaming endpoints
- approvals
- agent endpoints

ADD:
- business routes
- mall routes
- fashion routes
- CIA routes
- package routes
- Studio routes
- Builder routes
- opportunity routes

## Jarvis backend/services/
KEEP PATTERN:
- small services
- stateful runtime components
- activity streaming
- sessions
- dynamic agent definitions

ADD:
- investigation_service
- evidence_service
- score_service
- blockage_service
- opportunity_service
- package_service
- lead_service
- personalization_service
- proposal_service
- measurement_service
- learning_service
- connection_service
- publishing_service
- studio_service
- builder_service
- mall_service
- fashion_service
- business_tree_service

## Jarvis team_templates/agile_team.yaml
KEEP:
- PM orchestrates
- specialist roles
- dynamic team selection
- phase monitoring
- approvals/review

CHANGE:
- replace Jira/Confluence-centric project management with Zuxuru Project/Task/Approval objects where appropriate.

## Jarvis skills

KEEP concept:
Markdown/YAML skills loaded on demand.

Zuxuru skills:
- business-investigation
- public-visibility
- evidence-verification
- growth-diagnosis
- opportunity-detection
- hook-generation
- offer-generation
- lead-qualification
- personalization
- closing
- mall-intelligence
- tenant-intelligence
- business-tree
- fashion-brand
- fashion-content
- website-building
- studio-production
- publishing
- analytics
- measurement
- learning

## Important

The Jarvis repository is a reference runtime architecture.

Zuxuru is the actual product domain.

Do not simply rename Jarvis files and call it Zuxuru.
