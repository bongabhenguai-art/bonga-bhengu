# ZUXURU DATA MODEL

## Core tables/entities

Organisation
User
Business
BusinessLocation
BusinessRelationship
BusinessTree
Branch
Mall
Tenant
Person
Brand
Collection
Product
Platform
PlatformConnection
DigitalAsset
Evidence
VisibilityScore
GrowthBlockage
Opportunity
Hook
Offer
Lead
Customer
CustomerInteraction
Package
PackageLineItem
Proposal
Approval
Project
Task
Agent
AgentRun
Skill
Tool
Workflow
ContentAsset
Campaign
Publication
WebsiteProject
WebsiteVersion
Measurement
Metric
Experiment
Learning
AuditEvent
Notification

## Critical relationships

Business 1→N BusinessLocation
Business 1→N PlatformConnection
Business 1→N Evidence
Business 1→N VisibilityScore
Business 1→N Opportunity
Business 1→N Lead
Business 1→N Project

Mall 1→N Tenant
Tenant N→1 Business

BusinessTree 1→N Branch
Branch N→1 Business

Project 1→N Task
Project 1→N Approval
Project 1→N Measurement

AgentRun N→1 Workflow
AgentRun N→1 Business
AgentRun N→1 Project

## Evidence principle

Scores and recommendations should reference evidence records.

Do not store an unexplained score with no evidence trail.
